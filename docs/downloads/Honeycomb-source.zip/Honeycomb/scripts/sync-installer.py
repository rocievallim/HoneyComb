#!/usr/bin/env python3
"""Refresh the standalone Honeycomb installer from the editable source tree."""
import argparse
import base64
import hashlib
import io
from pathlib import Path
import re
import textwrap
import zipfile


def heredoc(text, tag, body=None):
    marker = f"<<'{tag}'\n"
    head, rest = text.split(marker, 1)
    previous, tail = rest.split(f"\n{tag}\n", 1)
    if body is None:
        return previous + "\n"
    if tag in body.splitlines():
        raise ValueError(f"Source contains the installer delimiter {tag}")
    if not body.endswith("\n"):
        body += "\n"
    return f"{head}{marker}{body}{tag}\n{tail}"


def updated_filee(source_dir, previous):
    files = {
        path.relative_to(source_dir).as_posix(): path.read_bytes()
        for path in sorted(source_dir.rglob("*"))
        if path.is_file()
        and not {"bin", "obj", ".DS_Store"}.intersection(path.relative_to(source_dir).parts)
    }
    if "src/Filee.Cli/Filee.Cli.csproj" not in files:
        raise ValueError("Filee CLI source is missing")
    with zipfile.ZipFile(io.BytesIO(previous)) as archive:
        if set(archive.namelist()) == set(files) and all(
            archive.read(name) == data for name, data in files.items()
        ):
            return previous
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w") as archive:
        for name, data in files.items():
            archive.writestr(zipfile.ZipInfo(name), data, compress_type=zipfile.ZIP_DEFLATED)
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Fail if the installer is out of sync")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    installer = root / "install-honeycomb.command"
    original = installer.read_text(encoding="utf-8")
    swift = (root / "main.swift").read_text(encoding="utf-8")
    updated = heredoc(original, "HONEYCOMB_SWIFT", swift)
    encoded = heredoc(original, "HONEYCOMB_FILEE_SOURCE")
    previous = base64.b64decode(encoded)
    payload = updated_filee(root / "vendor/filee-cli", previous)
    if payload != previous:
        encoded = "\n".join(textwrap.wrap(base64.b64encode(payload).decode("ascii"), 100))
        updated = heredoc(updated, "HONEYCOMB_FILEE_SOURCE", encoded)
    digest = hashlib.sha256(payload).hexdigest()
    updated, count = re.subn(r'(?m)^(    HC_EXT_HASH=)"[0-9a-f]{64}"$', rf'\g<1>"{digest}"', updated)
    if count != 1:
        raise ValueError("Filee source checksum anchor is missing or ambiguous")
    if args.check and updated != original:
        raise SystemExit("Installer needs regeneration. Run python3 scripts/sync-installer.py.")
    if updated != original:
        installer.write_text(updated, encoding="utf-8")
        print("Updated install-honeycomb.command.")
    else:
        print("install-honeycomb.command matches the source.")


if __name__ == "__main__":
    main()
